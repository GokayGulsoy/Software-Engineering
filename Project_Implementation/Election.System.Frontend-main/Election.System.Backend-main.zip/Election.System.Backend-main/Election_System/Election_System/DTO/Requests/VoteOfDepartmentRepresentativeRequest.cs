﻿namespace Election_System.DTO.Requests
{
    public class VoteOfDepartmentRepresentativeRequest
    {
        public int VoterStudentId { get; set; }
        public int CandidateStudentId { get; set; }

    }

}
