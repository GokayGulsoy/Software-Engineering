﻿using Election_System.Generics;
using Election_System.Models;

namespace Election_System.Repositories
{
    public interface IStudentRepository : IGenericRepository<Student>
    {

    }

}
