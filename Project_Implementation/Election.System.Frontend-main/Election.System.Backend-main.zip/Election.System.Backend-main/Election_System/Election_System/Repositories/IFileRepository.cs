﻿using Election_System.Generics;

namespace Election_System.Repositories
{
    public interface IFileRepository : IGenericRepository<Models.File>
    {

    }
}
