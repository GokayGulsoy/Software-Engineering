﻿namespace Election_System.Enumerations
{
    public enum Role
    {
        STUDENT_AFFAIR,
        FACULTY_REPRESENTATIVE,
        DEPARTMENT_REPRESENTATIVE,
        STUDENT
    }

}
