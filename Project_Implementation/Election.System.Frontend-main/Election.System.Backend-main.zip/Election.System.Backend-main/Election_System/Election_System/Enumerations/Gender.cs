﻿namespace Election_System.Enumerations
{
    public enum Gender
    {
        MALE,
        FEMALE
    }

}
