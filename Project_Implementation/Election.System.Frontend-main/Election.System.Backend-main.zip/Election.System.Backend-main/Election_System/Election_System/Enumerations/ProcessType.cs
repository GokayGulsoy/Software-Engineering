﻿namespace Election_System.Enumerations
{
    public enum ProcessType
    {
        DEPARTMENT_CANDIDACY,
        DEPARTMENT_REPRESENTATIVE,
        FACULTY_CANDIDACY,
        FACULTY_REPRESENTATIVE,
        QUALIFICATION_CONTROL
    }

}
