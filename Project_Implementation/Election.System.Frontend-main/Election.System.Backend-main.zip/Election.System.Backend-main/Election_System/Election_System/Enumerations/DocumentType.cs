﻿namespace Election_System.Enumerations
{
    public enum DocumentType
    {
        STUDENT_CERTIFICATE,
        CRIMINAL_RECORD,
        PARTY_MEMBERSHIP,
        GPA_TRANSCRIPT
    }

}
