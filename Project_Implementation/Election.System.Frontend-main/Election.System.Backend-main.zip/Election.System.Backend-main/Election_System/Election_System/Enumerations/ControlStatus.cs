﻿namespace Election_System.Enumerations
{
    public enum ControlStatus
    {
        WAITING,
        APPROVED,
        DENIED,
        UNACCEPTABLE
    }

}
